# Tuneame_la_guitarra
Este es un proyecto ambicioso para dos materias, el mejor profe del semestre vs el kratos. 
